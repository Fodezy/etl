import json
import pandas as pd
import os

# Determine directories relative to this script
script_dir = os.path.dirname(os.path.abspath(__file__))

# classification_output.json sits in the parent directory of 'scripts'
input_json = os.path.join(script_dir, '..', 'classification_output.json')

# CSV output goes into etl/csv, which is two levels up from scripts
etl_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
output_dir = os.path.join(etl_dir, 'csv')

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Load the classification JSON data
with open(input_json, 'r') as f:
    data = json.load(f)

# Prepare lists for each category
courses_rows = []
generic_rows = []

for item in data.get('results', []):
    code = item.get('code')
    for chunk_info in item.get('chunks', []):
        chunk = chunk_info.get('chunk')
        category = chunk_info.get('category')
        if category == 'courses':
            courses_rows.append({'course_code': code, 'chunk': chunk})
        elif category == 'generic':
            generic_rows.append({'course_code': code, 'chunk': chunk})

# Create DataFrames
df_courses = pd.DataFrame(courses_rows)
df_generic = pd.DataFrame(generic_rows)

# Paths for CSVs
courses_csv_path = os.path.join(output_dir, "courses_chunks.csv")
generic_csv_path = os.path.join(output_dir, "generic_chunks.csv")

# Write CSVs
df_courses.to_csv(courses_csv_path, index=False)
df_generic.to_csv(generic_csv_path, index=False)

print(f"Written courses-category CSV to: {courses_csv_path}")
print(f"Written generic-category CSV to: {generic_csv_path}")
