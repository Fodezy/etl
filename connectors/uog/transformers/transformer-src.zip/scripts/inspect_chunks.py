# scripts/inspect_chunks.py
import pandas as pd

# adjust path if your CSV lives elsewhere
df = pd.read_csv("csv/courses.csv")
samples = df["chunk"].sample(25, random_state=1).tolist()
print("Random chunk samples:\n", "\n".join(samples))
