import json
import os
import sys

# Add the project root to the Python path to allow for absolute imports
script_dir = os.path.dirname(__file__)
root_dir = os.path.abspath(os.path.join(script_dir, '..'))
src_dir = os.path.join(root_dir, 'src')
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

# Import the main entry point function
from ..src.parse import parse_prereq

def main():
    """
    Runs the prerequisite parsing on a JSON file of courses and outputs
    a detailed classification report.
    """
    data_path = os.path.join(root_dir, 'testReqs', 'all_filtered_courses.json')

    if not os.path.exists(data_path):
        print(f"Error: data file not found at {data_path}")
        return

    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    results = []
    counts = {}
    generic_items = []
    total = 0

    for course in data:
        total += 1
        code = course.get('code', '<unknown>')
        prereq_text = course.get('prerequisites', '')
        
        entry = {
            'code': code,
            'prerequisites': prereq_text,
            'chunks': []
        }

        # --- THIS IS THE KEY CHANGE ---
        # Pass debug=True to activate the print statements inside parse_prereq.
        # We will only run it for the specific problematic course code.
        if code == "PHYS*2330":
            print(f"\n--- DEBUGGING {code} ---")
            parsed_results = parse_prereq(prereq_text, debug=True)
        else:
            parsed_results = parse_prereq(prereq_text, debug=False)
        # --- END OF CHANGE ---

        entry['chunks'] = parsed_results

        for item in parsed_results:
            cat = item['category']
            counts[cat] = counts.get(cat, 0) + 1
            if cat == 'generic':
                generic_items.append({
                    'code': code,
                    'raw': prereq_text,
                    'chunk': item['chunk']
                })
        results.append(entry)

    summary = {
        'counts': counts,
        'total': total,
        'generic_items': generic_items
    }

    output = {
        'results': results,
        'summary': summary
    }

    output_path = os.path.join(root_dir, 'classification_output.json')
    with open(output_path, 'w', encoding='utf-8') as out_f:
        json.dump(output, out_f, indent=2)

    print(f"Classification results written to {output_path}")

if __name__ == '__main__':
    main()
