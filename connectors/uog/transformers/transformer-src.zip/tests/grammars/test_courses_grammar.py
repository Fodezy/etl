# tests/grammars/test_courses_grammar.py
import pytest
from lark import Lark, UnexpectedInput
import os

# Get the directory of the current test file (test_courses_grammar.py)
current_test_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the absolute path to the 'grammars' directory where courses.lark and common_tokens.lark reside.
# Based on the path 'connectors/uog/transformers/src/parser/grammars/courses.lark'
# and the test file at 'connectors/uog/transformers/tests/grammars/test_courses_grammar.py'
# We need to go up two directories from 'tests/grammars' to 'transformers/',
# then down into 'src/parser/grammars'.
grammars_dir = os.path.join(current_test_dir, '..', '..', 'src', 'parser', 'grammars')

# Now, open the main grammar file, providing the import_paths
GRAMMAR = Lark.open(
    os.path.join(grammars_dir, "courses.lark"), # Provide the full path to courses.lark
    # REMOVED: rel_to_path=grammars_dir,       # This option is no longer supported in newer Lark versions
    import_paths=[grammars_dir],                # Tell Lark to look here for imported grammars (like common_tokens.lark)
    parser="earley",
    propagate_positions=False,
    maybe_placeholders=False,
)

GOLDEN = [
    "STAT*2050",
    "FREN*2060",
    "NUTR*3210",
    "BIOL*3060 or BIOL*3130",
    "DTM*1300",
    "HORT*2450",
    "(MBG*3080 or MICR*3240)",
    "NANO*2000",
    "MICR*3330",
    "BIOL*3670",
    "MATH*2270",
    "(AHSS*1210 or MDST*1040)",
    "BUS*4550",
    "FREN*2060",
    "CTS*1000",
    "(FOOD*3030 or FOOD*3050)",
    "(CHEM*2400 or CHEM*2480)",
    "UNIV*6080",
    "MUSC*1720",
    "CIS*2500",
    "LARC*3060",
    "HK*3501",
]

@pytest.mark.parametrize("chunk", GOLDEN)
def test_courses_chunk_parses(chunk):
    # should parse end-to-end without UnexpectedInput
    GRAMMAR.parse(chunk)