# tests/test_split.py

import pytest
from ..src.parser.split import split_clauses

@pytest.mark.parametrize(
    "raw, expected",
    [
        # Single course code with trailing commentary
        ("ENGL*1080 - Must be completed prior to taking this course.", ["ENGL*1080"]),
        # OR without parentheses
        ("POLS*1400 or POLS*2300 - Must be completed prior to taking this course.",
         ["POLS*1400 or POLS*2300"]),
        # Generic phrase
        ("All Phase 1 courses - Must be taken either prior to or at the same time as this course.",
         ["All Phase 1 courses"]),
        # Multiple top-level clauses with nested OR parentheses
        ("BIOL*3450, (STAT*2040 or STAT*2230), (ZOO*3210 or ZOO*3610) - Must be completed prior to taking this course.",
         ["BIOL*3450", "(STAT*2040 or STAT*2230)", "(ZOO*3210 or ZOO*3610)"]),
        # Mixed top-level commas and parentheses + final code
        ("ANTH*2230, (ANTH*2160 or ANTH*2180), SOAN*2120 - Must be completed prior to taking this course.",
         ["ANTH*2230", "(ANTH*2160 or ANTH*2180)", "SOAN*2120"]),
        # Simple comma split
        ("BIOL*2400, ZOO*2090 - Must be completed prior to taking this course.",
         ["BIOL*2400", "ZOO*2090"]),
        # Credits clause
        ("2.00 credits - Must be completed prior to taking this course.",
         ["2.00 credits"]),
        # Course or work experience with trailing period
        ("CIS*2500 or work experience in a related field. - Must be completed prior to taking this course.",
         ["CIS*2500 or work experience in a related field"]),
        # Two separate parentheses
        ("(HTM*2020 or SPMT*2020), (ECON*2560 or FIN*2000) - Must be completed prior to taking this course.",
         ["(HTM*2020 or SPMT*2020)", "(ECON*2560 or FIN*2000)"]),
        # Nested commas inside parentheses
        ("BIOC*2580, (1 of ANSC*3080, BIOM*3200, HK*3810, ZOO*3200, ZOO*3600) - Must be completed prior to taking this course.",
         ["BIOC*2580", "(1 of ANSC*3080, BIOM*3200, HK*3810, ZOO*3200, ZOO*3600)"]),
        # Including keyword without separators
        ("5.00 credits including AHSS*1160 - Must be completed prior to taking this course.",
         ["5.00 credits including AHSS*1160"]),
        # List of three codes
        ("1 of BUS*2090, BUS*2220, HROB*2090 - Must be completed prior to taking this course.",
         ["1 of BUS*2090, BUS*2220, HROB*2090"]),
        # Recommended instead of Must
        ("IDEV*6800 - Recommended prior to taking this course, but is not required.",
         ["IDEV*6800"]),
        # Completion phrasing with including
        ("Completion of 6.00 credits of ENGG courses including ENGG*2100 - Must be completed prior to taking this course.",
         ["Completion of 6.00 credits of ENGG courses including ENGG*2100"]),
        # N-of without parentheses
        ("1 of BIOL*1050, BIOL*1070, BIOL*1080, BIOL*1090 - Must be completed prior to taking this course.",
         ["1 of BIOL*1050, BIOL*1070, BIOL*1080, BIOL*1090"]),
        # N-of with parentheses
        ("(1 of ANTH*2160, ANTH*2180, ANTH*2230) - Must be completed prior to taking this course.",
         ["(1 of ANTH*2160, ANTH*2180, ANTH*2230)"]),
         # 4U
        ("4U Chemistry (or equivalent) or CHEM*1060 - Must be completed prior to taking this course.",
         ["4U Chemistry (or equivalent) or CHEM*1060"]),
    ],
)
def test_split_clauses(raw, expected):
    assert split_clauses(raw) == expected
