import pytest
from ..src.parser.classify import classify

@ pytest.mark.parametrize(
    "chunk, expected",
    [
        # subjectlevel
        ("3000 or 4000 level BIOC, MBG, MCB OR MICR courses", "subjectlevel"),

        # admission
        ("Admission to the Latin America semester", "admission"),
        ("admission to Graduate Diploma Program", "admission"),

        # credits
        ("2.00 credits", "credits"),
        ("A minimum of 9.00 credits", "credits"),

        # program
        ("registration in Diploma Program", "program"),

        # grade
        ("minimum grade 065", "grade"),

        # average
        ("cumulative average of 75%", "average"),
        ("Minimum average of 70% across all work", "average"),

        # experience
        ("plus 120 hours of leadership experience", "experience"),
        ("and a minimum of 700 hours of verified work experience", "experience"),

        # progression
        ("students must have completed 6 semesters in an appropriate program", "progression"),

        # N-of
        ("1 of BIOL*1050, BIOL*1070", "nof"),
        ("(2 of CHEM*3430, CHEM*3640, CHEM*3650)", "nof"),

        # phase
        ("All Phase 1 courses", "phase"),
        ("all phase 2 courses", "phase"),

        # highschool
        ("4U Chemistry or equivalent", "highschool"),
        ("such as grade 12 French Immersion", "highschool"),

        # workterm / co-op
        ("COOP*G1", "workterm"),
        ("COOP*G2", "workterm"),

        # courses
        ("AGR*1110 or AGR*1250", "courses"),
        ("MBG*3350", "courses"),

        # generic
        ("foo bar baz", "generic"),
        ("Restriction: Permission of instructor", "generic"),
    ],
)
def test_classify(chunk, expected):
    assert classify(chunk) == expected
