import json
import subprocess
from pathlib import Path

def test_cli_end_to_end(tmp_path):
    # Prepare a minimal input JSON
    in_file = tmp_path / "in.json"
    out_file = tmp_path / "out.json"
    in_file.write_text(json.dumps([
        {"code": "AGR*1110", "prerequisites": "AGR*1110"}
    ]))

    # Compute the module path for the CLI entrypoint
    # Starting from this test file: tests/ → transformers/ → uog/ → connectors/
    repo_root = Path(__file__).parents[3]
    # We'll call the module `connectors.uog.transformers.src.parse_prerequisite`
    module_name = "connectors.uog.transformers.src.parse_prerequisite"

    result = subprocess.run(
        ["python", "-m", module_name, str(in_file), str(out_file)],
        cwd=str(repo_root),
        capture_output=True,
        text=True,
    )
    # Ensure the process exited cleanly
    assert result.returncode == 0, f"STDERR:\n{result.stderr}"

    # Verify stdout mentions the write
    assert f"Wrote 1 parsed entries to {out_file}" in result.stdout

    # Inspect the output JSON
    data = json.loads(out_file.read_text())
    assert len(data) == 1
    assert data[0]["code"] == "AGR*1110"
    # parsed should be a list with one dict containing category "courses"
    assert data[0]["parsed"][0]["category"] == "courses"
