# import pytest
# from ..src.parse import parse_prereq

# def test_parse_simple_course_list():
#     raw = "AGR*1110 or AGR*1250 - Must be completed prior to taking this course."
#     parsed = parse_prereq(raw)
#     # Expect exactly one chunk
#     assert len(parsed) == 1
#     entry = parsed[0]
#     assert entry["category"] == "courses"
#     # The AST should be a Lark Tree with data="start"
#     assert hasattr(entry["ast"], "data") and entry["ast"].data == "start"

# def test_parse_mixed_clauses():
#     raw = "2.00 credits, (1 of BIOL*1050, BIOL*1070) and a minimum of 700 hours of work experience."
#     parsed = parse_prereq(raw)
#     cats = [e["category"] for e in parsed]
#     assert cats == ["credits", "nof", "experience"]
