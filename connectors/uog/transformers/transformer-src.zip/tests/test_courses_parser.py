import pytest
from ..src.parser.parsers import PARSERS
from lark import UnexpectedInput

@pytest.fixture
def courses_parser():
    return PARSERS["courses"]

@pytest.mark.parametrize("chunk", [
    "AGR*1110",
    "AGR*1110 or AGR*1250",
    "(STAT*2040 or STAT*2230)",
    "BUS*2090 and HROB*2090",
    "(BUS*2090 and HROB*2090) or ZOO*1050",
])
def test_courses_parse_success(courses_parser, chunk):
    # Should not raise
    tree = courses_parser.parse(chunk.upper())
    assert tree  # you could also inspect tree.data == "start"

@pytest.mark.parametrize("bad", [
    "foo bar baz",
    "1234 ABCD",
    "AGR*1110, POLS*2300",  # comma not allowed top-level
])
def test_courses_parse_fail(courses_parser, bad):
    with pytest.raises(UnexpectedInput):
        courses_parser.parse(bad.upper())
