# Course Prerequisite Parser

This module provides tools for parsing, classifying, and transforming course prerequisite strings into structured data. It's designed to handle the complex prerequisite statements found in university course catalogs.

## Overview

The prerequisite parser system works in three main stages:

1. **Splitting**: Breaking complex prerequisite statements into logical chunks
2. **Classification**: Identifying the type of each chunk (courses, credits, etc.)
3. **Parsing**: Converting each chunk into a structured representation
4. **Transformation**: Converting parsed syntax trees into structured dictionaries

## Directory Structure

```
transformers/
├── scripts/
│   └── prototype_classifier.py
├── src/
│   ├── parser/
│   │   ├── grammars/                 # Lark grammar definitions
│   │   │   ├── common_tokens.lark    # (Renamed for clarity) General-purpose tokens
│   │   │   ├── courses.lark          # Course-specific grammar
│   │   │   ├── credits.lark          # Credit-related grammar (e.g., "0.50 credits")
│   │   │   ├── high_school.lark      # High school specific grammar
│   │   │   └── other_categories.lark # For other, less common, grammar patterns
│   │   │
│   │   ├── requisite_parser/         # NEW: Core parsing logic for different requisite types
│   │   │   ├── __init__.py           # Makes it a Python package
│   │   │   ├── loader.py             # Handles loading Lark grammars
│   │   │   ├── base_transformer.py   # Base class for all specific transformers (optional, but good practice)
│   │   │   ├── course_transformer.py # Transformer specifically for 'courses.lark'
│   │   │   ├── credit_transformer.py # Transformer for 'credits.lark'
│   │   │   ├── high_school_transformer.py # Transformer for 'high_school.lark'
│   │   │   ├── nof_transformer.py    # Transformer for N-of expressions (moved here from case_transformers)
│   │   │   └── main_parser.py        # The central orchestrator that uses the above components
│   │   │
│   │   ├── classify.py               # Chunk classification logic (remains here)
│   │   ├── split.py                  # Prerequisite splitting logic (remains here)
│   │   └── orchestrator.py           # (Potentially renamed/merged, see below)
│   │
│   ├── case_transformers/            # This directory might become redundant or renamed
│   │   # No longer needed if nof_transformer moves to requisite_parser
│   │   # Maybe for *post-parsing* transformations that cross categories?
│   │
│   ├── parse.py                      # Main parsing entry point (potentially simplified)
│   └── parse_prerequisite.py         # CLI entry point (remains as your script)
├── testReqs/
└── tests/
```



## How It Works

### 1. Splitting (split.py)

The `split_clauses()` function breaks down complex prerequisite statements into logical chunks. For example:

```
"BIOL*3450, (STAT*2040 or STAT*2230), (ZOO*3210 or ZOO*3610) - Must be completed prior to taking this course."
```

Gets split into:
```
["BIOL*3450", "(STAT*2040 or STAT*2230)", "(ZOO*3210 or ZOO*3610)"]
```

Special cases are handled for:
- Credits with "including" clauses
- N-of expressions
- Work experience requirements

### 2. Classification (classify.py)

Each chunk is classified into one of these categories:
- `courses`: Lists of course codes (e.g., "BIOL*1070 or BIOL*1080")
- `nof`: N-of expressions (e.g., "1 of BIOL*1050, BIOL*1070, BIOL*1080")
- `credits`: Credit requirements (e.g., "4.00 credits")
- `credits_includes`: Credits with included courses (e.g., "15.00 credits including ANSC*3080")
- `program`: Program registration statements
- `phase`: Phase-based requirements (e.g., "All Phase 1 courses")
- `highschool`: High school prerequisites (e.g., "4U Chemistry")
- `admission`: Admission statements
- `average`: GPA requirements
- `experience`: Experience requirements
- `progression`: Semester-based progression
- `workterm`: Co-op/work term codes
- `subjectlevel`: Subject-level requirements
- `generic`: Fallback for unclassified chunks

### 3. Parsing (parsers.py)

Each classified chunk is parsed using a specialized grammar defined in Lark format. The grammars are in the `grammars/` directory:

- `courses.lark`: For parsing course code lists
- `nof.lark`: For parsing "N of X, Y, Z" expressions
- `credits.lark`: For parsing credit requirements
- `credits_includes.lark`: For parsing credits with included courses
- etc.

The `RequisiteTransformer` class in `parsers.py` converts the parsed syntax trees into structured dictionaries.

### 4. Transformation (nof_transformer.py)

The `NofTransformer` class specifically handles the transformation of "N of courses" expressions into a structured dictionary format:

```json
{
  "type": "NOF",
  "number": 2,
  "courses": ["BIOL*1050", "BIOL*1070", "BIOL*1080", "BIOL*1090"]
}
```

This transformer is used to process the parsed syntax tree from the nof.lark grammar.

## Grammar Files

The `grammars/` directory contains Lark grammar files that define the syntax for different types of prerequisite statements:

### Common Grammar Components

- **my_prereq_common.lark**: Defines shared tokens and rules used across multiple grammars:
  - Common separators: `COMMA`, `OR`, `AND`, `LPAR`, `RPAR`, etc.
  - Domain-specific keywords: `OF`, `IN`, `CREDITS`, `INCLUDING`, etc.
  - Course code pattern: `COURSE_CODE` (e.g., "CHEM*1050")
  - Text phrases: `TEXT_PHRASE` for capturing descriptive text
  - Group openers/closers: `group_open`, `group_close`

### Course-Related Grammars

- **courses.lark**: Parses lists of course codes with logical operators
  - Handles course sequences: "BIOL*1070, BIOL*1080"
  - Supports nested expressions: "(BIOL*1070 or BIOL*1080)"
  - Allows mixed bracket types and text phrases

- **nof.lark**: Parses "N of X, Y, Z" expressions
  - Example: "1 of BIOL*1050, BIOL*1070, BIOL*1080"
  - Supports various bracket combinations: `()`, `[]`, `(]`, `[)`

- **workterm.lark**: Identifies co-op work term codes
  - Simple grammar that matches course codes for work terms

### Credit-Related Grammars

- **credits.lark**: Parses credit requirements
  - Example: "4.00 credits" or "a minimum of 10.00 credits"
  - Handles optional prefixes like "A" or "minimum of"

- **credits_includes.lark**: Parses credits with included courses
  - Example: "15.00 credits including 1 of ANSC*3080, ANSC*4050"
  - Supports complex includes: "N of courses", "N in courses", "N credits in SUBJECT"
  - Handles level-based requirements: "3.00 credits at 3000-level"

- **subject_credits.lark**: Parses credit requirements in specific subjects
  - Example: "2.00 credits in BIOLOGY" or "3.00 credits in PHYSICS OR CHEMISTRY"

### Program and Academic Status Grammars

- **program.lark**: Identifies program registration requirements
  - Example: "REGISTRATION IN BCOMM"

- **phase.lark**: Parses phase-based requirements
  - Example: "ALL PHASE 1 COURSES"

- **progression.lark**: Identifies semester progression requirements
  - Example: "COMPLETION OF 4 SEMESTERS"

- **admission.lark**: Identifies admission requirements
  - Example: "ADMISSION TO ENGINEERING"

### Other Requirement Types

- **average.lark**: Parses GPA requirements
  - Example: "70%" or "CUMULATIVE AVERAGE"

- **experience.lark**: Identifies experience requirements
  - Example: "100 HOURS OF EXPERIENCE"

- **highschool.lark**: Parses high school prerequisites
  - Example: "4U CHEMISTRY" or "GRADE 12 CALCULUS"

- **generic.lark**: Fallback grammar for complex boolean expressions
  - Combines other grammar types with logical operators
  - Handles nested expressions with AND/OR operators

## Usage

### Basic Usage

```python
from src.parse import parse_prereq

# Parse a prerequisite string
result = parse_prereq("BIOL*1070 or BIOL*1080 - Must be completed prior to taking this course.")
print(result)
```

### Command Line Usage

```bash
python -m connectors.uog.transformers.src.parse_prerequisite input.json output.json
```

## Testing

Unit tests are in the `tests/` directory. Run them with pytest:

```bash
pytest tests/
```

## Test Data

Sample prerequisite data is available in the `testReqs/` directory:
- `all_filtered_courses.json`: Complete dataset
- `filtered_courses.json`: Smaller subset
- `random_filtered_courses_*.json`: Random samples of different sizes

## Output Format

The parser produces structured JSON output with the following format:

```json
[
  {
    "chunk": "1 of BIOL*1050, BIOL*1070, BIOL*1080, BIOL*1090",
    "category": "nof",
    "parsed": {
      "type": "NOF",
      "number": 1,
      "courses": ["BIOL*1050", "BIOL*1070", "BIOL*1080", "BIOL*1090"]
    }
  }
]
```

## Key Components

1. **Grammar Definitions**: Lark grammar files define the syntax for each prerequisite type
2. **Transformers**: Convert parsed syntax trees into structured dictionaries
   - `RequisiteTransformer` in parsers.py for general transformations
   - `NofTransformer` in nof_transformer.py specifically for N-of expressions
3. **Classifier**: Determines the appropriate parser for each chunk
4. **Splitter**: Breaks complex statements into logical chunks

## Development

To extend the parser:

1. Add new grammar files in `grammars/` for new prerequisite types
2. Update the classifier in `classify.py` to recognize the new type
3. Add transformer methods in `parsers.py` or create specialized transformers like `nof_transformer.py`
4. Add tests in `tests/` to verify the new functionality