# D:\CourseMap\etl\connectors\uog\transformers\src\parser\parsers.py

from pathlib import Path
from lark import Lark, UnexpectedInput, Transformer, Token, Tree
from typing import Any, Dict, List, Optional
import json
import re

GRAMMAR_DIR = Path(__file__).parent / "grammars"

class RequisiteTransformer(Transformer):
    def __init__(self, debug: bool = False):
        self.debug = debug
        super().__init__()
    
    def credits(self, items):
        if self.debug:
            print(f"DEBUG: Entering credits transformer for items: {items}")

        credit_value = None
        for item in items:
            if isinstance(item, Token) and item.type == 'DECIMAL':
                try:
                    credit_value = float(item.value)
                    break
                except ValueError:
                    if self.debug:
                        print(f"DEBUG: Could not convert '{item.value}' to float in credits transformer.")
        
        if credit_value is not None:
            result = {"type": "CREDITS_AMOUNT", "amount": credit_value}
        else:
            if self.debug:
                print(f"WARNING: 'credits' transformer could not extract a valid credit amount from: {items}")
            result = {"type": "ERROR_CREDITS_TRANSFORM", "original_items": self._transform_children_for_error(items)}
        
        if self.debug:
            print(f"DEBUG: Exiting credits transformer with result: {result}")
        return result

    def start(self, items):
        if self.debug:
            print(f"DEBUG: 'start' rule transformed. Items: {items}")
        if items and isinstance(items[0], dict):
            return items[0]
        result = {"type": "UNEXPECTED_START_OUTPUT", "items": [self._transform_child(item) for item in items]}
        if self.debug:
            print(f"DEBUG: Exiting start transformer with result: {result}")
        return result

    def courses__course_item(self, items):
        """
        Transforms a 'course_item' rule from courses.lark.
        This handles either a direct COURSE_CODE or a nested (course_list).
        """
        if self.debug:
            print(f"DEBUG: Entering courses__course_item transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: courses__course_item item[{i}]: Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}")

        # Case 1: Simple COURSE_CODE token
        if len(items) == 1 and isinstance(items[0], Token) and items[0].type.endswith('__COURSE_CODE'):
            return {"type": "SINGLE_COURSE", "course": str(items[0])}
        
        # Case 2: Nested grouped course_list: group_open course_list group_close
        elif (len(items) == 3 and
              isinstance(items[0], Token) and items[0].type.endswith('__group_open') and
              isinstance(items[2], Token) and items[2].type.endswith('__group_close')):
            
            nested_course_list_result = self.transform(items[1]) 
            
            if isinstance(nested_course_list_result, dict) and nested_course_list_result.get('type') == 'COURSES':
                return nested_course_list_result
            else:
                if self.debug:
                    print(f"WARNING: courses__course_item: Nested group content did not transform to COURSES dict as expected: {nested_course_list_result}")
                return nested_course_list_result if isinstance(nested_course_list_result, dict) and nested_course_list_result.get('type', '').startswith('ERROR_') \
                       else {"type": "ERROR_NESTED_GROUP_CONTENT", "items": [self._transform_child(item) for item in items]}
        
        else:
            if self.debug:
                print(f"WARNING: courses__course_item transformer received unhandled items: {items}")
            return {"type": "ERROR_SINGLE_COURSE_ITEM", "items": [self._transform_child(item) for item in items]}

    def include_item(self, items):
        if self.debug:
            print(f"DEBUG: Entering include_item transformer for items: {items}")
        if len(items) == 1:
            result = self.transform(items[0]) if isinstance(items[0], Tree) else items[0]
        else:
            if self.debug:
                print(f"WARNING: include_item transformer received unexpected items: {items}")
            result = {"type": "ERROR_INCLUDE_ITEM", "items": [self._transform_child(item) for item in items]}
        if self.debug:
            print(f"DEBUG: Exiting include_item transformer with result: {result}")
        return result

    def course_list(self, items):
        """
        Transforms a list of courses.
        `items` here will be transformed `courses__course_sequence` dictionaries
        and potentially raw COMMA/OR tokens.
        """
        if self.debug:
            print(f"DEBUG: Entering course_list transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: course_list item[{i}]: Raw Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}")

        courses: List[str] = []
        for item in items:
            processed_item = self.transform(item) if isinstance(item, Tree) else item 

            if self.debug:
                print(f"  DEBUG: course_list - Processed item: Type={type(processed_item)}, Content={processed_item}")

            if isinstance(processed_item, dict):
                if processed_item.get('type') == 'COURSE_SEQUENCE' and 'courses' in processed_item:
                    courses.extend([c.strip() for c in processed_item['courses'] if isinstance(c, str) and c.strip()])
                elif processed_item.get('type') == 'COURSES' and 'courses' in processed_item:
                    courses.extend([c.strip() for c in processed_item['courses'] if isinstance(c, str) and c.strip()])
                elif processed_item.get('type') == 'SINGLE_COURSE' and 'course' in processed_item:
                    if isinstance(processed_item['course'], str):
                        stripped_course = processed_item['course'].strip()
                        if stripped_course: 
                            courses.append(stripped_course)
                # NEW: Handle High School courses that might pass through this list if misclassified or part of generic
                elif processed_item.get('type') == 'HIGHSCHOOL_COURSE' and 'name' in processed_item:
                    stripped_name = processed_item['name'].strip()
                    if stripped_name:
                        courses.append(stripped_name)
                # NEW: Handle generic high school phrases that might pass through
                elif processed_item.get('type') == 'HIGHSCHOOL_PHRASE' and 'text' in processed_item:
                    stripped_text = processed_item['text'].strip()
                    if stripped_text:
                        courses.append(stripped_text)
                elif processed_item.get('type') == 'NOF':
                    if 'courses' in processed_item and isinstance(processed_item['courses'], list):
                        courses.extend([c.strip() for c in processed_item['courses'] if isinstance(c, str) and c.strip()])
                    else:
                        if self.debug:
                            print(f"WARNING: course_list - NOF transformed item has unexpected 'courses' structure: {processed_item}")
                        courses.append(f"UNRESOLVED_NOF:{json.dumps(processed_item)}")
                else:
                    if self.debug:
                        print(f"WARNING: course_list received unexpected transformed dict type: {processed_item.get('type')}, data: {processed_item}")
                    courses.append(f"UNHANDLED_DICT:{json.dumps(processed_item)}")
            elif isinstance(processed_item, Token):
                if self.debug:
                    print(f"  DEBUG: course_list - Ignoring token: {processed_item.type}")
            else:
                if self.debug:
                    print(f"WARNING: course_list received unexpected raw item type: {type(processed_item)} - {processed_item}")
                stripped_item = str(processed_item).strip()
                if stripped_item: 
                    courses.append(stripped_item)

        result = {"type": "COURSES", "courses": courses}
        if self.debug:
            print(f"DEBUG: Exiting course_list transformer with result: {result}, courses length: {len(courses)}")
        return result

    def courses__course_sequence(self, items):
        """
        Transforms a 'course_sequence' rule from courses.lark.
        This group contains one or more course_item's that are implicitly space-separated.
        Outputs: A dictionary containing a list of course strings.
        """
        if self.debug:
            print(f"DEBUG: Entering courses__course_sequence transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: courses__course_sequence item[{i}]: Raw Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}")

        sequence_courses: List[str] = []
        for item in items: # These items are the children of the course_sequence rule (course_item Trees or Tokens)
            processed_item = self.transform(item) if isinstance(item, Tree) else item
            
            if self.debug:
                print(f"  DEBUG: courses__course_sequence - Processed item: Type={type(processed_item)}, Content={processed_item}")

            if isinstance(processed_item, dict):
                if processed_item.get('type') == 'SINGLE_COURSE' and 'course' in processed_item:
                    if isinstance(processed_item['course'], str):
                        stripped_course = processed_item['course'].strip()
                        if stripped_course:
                            sequence_courses.append(stripped_course)
                elif processed_item.get('type') == 'COURSES' and 'courses' in processed_item:
                    if self.debug:
                        print(f"  DEBUG: courses__course_sequence - Flattening nested COURSES dict: {processed_item['courses']}")
                    sequence_courses.extend([c.strip() for c in processed_item['courses'] if isinstance(c, str) and c.strip()])
                # NEW: Handle High School courses from highschool grammar
                elif processed_item.get('type') == 'HIGHSCHOOL_COURSE' and 'name' in processed_item:
                    stripped_name = processed_item['name'].strip()
                    if stripped_name:
                        sequence_courses.append(stripped_name)
                # NEW: Handle generic high school phrases from highschool grammar
                elif processed_item.get('type') == 'HIGHSCHOOL_PHRASE' and 'text' in processed_item:
                    stripped_text = processed_item['text'].strip()
                    if stripped_text:
                        sequence_courses.append(stripped_text)
                elif processed_item.get('type', '').startswith('ERROR_'):
                    error_identifier = processed_item.get('chunk', processed_item.get('error', 'UNKNOWN_ERROR_SOURCE'))
                    if 'items' in processed_item and isinstance(processed_item['items'], list):
                        reconstructed_error_text = " ".join([
                            (item['value'] if isinstance(item, dict) and 'value' in item else str(item))
                            for item in processed_item['items'] if item is not None and (isinstance(item, dict) or str(item).strip())
                        ]).strip()
                        if reconstructed_error_text:
                            error_identifier = f"'{reconstructed_error_text}'"
                    
                    if self.debug:
                        print(f"WARNING: courses__course_sequence received error dict from child transformation: {processed_item.get('type')}, data: {processed_item}")
                    sequence_courses.append(f"PARSE_ERROR_ITEM:{error_identifier}")
                else:
                    if self.debug:
                        print(f"WARNING: courses__course_sequence received unexpected dict type from child transformation: {processed_item.get('type')}, data: {processed_item}")
                    sequence_courses.append(f"UNHANDLED_DICT_IN_SEQ_FALLBACK:{json.dumps(processed_item)}")
            elif isinstance(processed_item, Token) and processed_item.type == 'COURSE_CODE':
                if self.debug:
                    print(f"  DEBUG: courses__course_sequence - Appending direct COURSE_CODE token: {processed_item.value}")
                stripped_course = str(processed_item).strip()
                if stripped_course: 
                    sequence_courses.append(stripped_course)
            # NEW: Handle direct high school tokens if they bypass initial transformation
            elif isinstance(processed_item, Token) and processed_item.type == 'DIGITU': # For 4U, 12U
                 stripped_value = str(processed_item.value).strip()
                 if stripped_value:
                     sequence_courses.append(stripped_value)
            elif isinstance(processed_item, Token) and processed_item.type == 'OAC': # For OAC
                 stripped_value = str(processed_item.value).strip()
                 if stripped_value:
                     sequence_courses.append(stripped_value)
            elif isinstance(processed_item, Token) and processed_item.type == 'WORD': # For general words in high school phrases
                 stripped_value = str(processed_item.value).strip()
                 if stripped_value:
                     sequence_courses.append(stripped_value)
            else:
                if self.debug:
                    print(f"WARNING: courses__course_sequence received unexpected raw item type: {type(processed_item)} - {processed_item}")
                stripped_item = str(processed_item).strip()
                if stripped_item: 
                    sequence_courses.append(stripped_item)

        result = {"type": "COURSE_SEQUENCE", "courses": sequence_courses}
        if self.debug:
            print(f"DEBUG: Exiting courses__course_sequence transformer with result: {result}, courses length: {len(sequence_courses)}")
        return result

    # --- NEW High School Specific Transformers ---
    def highschool__high_school_expression(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__high_school_expression transformer for items: {items}")
        # high_school_expression -> high_school_list | high_school_item
        if items and isinstance(items[0], dict):
            return items[0]
        return {"type": "HIGHSCHOOL_EXPRESSION_ERROR", "items": [self._transform_child(item) for item in items]}

    def highschool__high_school_list(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__high_school_list transformer for items: {items}")
        high_school_courses = []
        for item in items:
            processed_item = self.transform(item) if isinstance(item, Tree) else item
            if isinstance(processed_item, dict) and processed_item.get('type') in ['HIGHSCHOOL_COURSE', 'HIGHSCHOOL_PHRASE']:
                high_school_courses.append(processed_item.get('name') or processed_item.get('text'))
            elif isinstance(processed_item, Token) and processed_item.type == 'COURSE_CODE':
                high_school_courses.append(str(processed_item.value).strip())
            elif isinstance(processed_item, Token) and processed_item.type in ['COMMA', 'OR_TEXT']:
                continue # Ignore separators
            else:
                if self.debug:
                    print(f"WARNING: highschool__high_school_list received unexpected item: {processed_item}")
                high_school_courses.append(f"UNHANDLED_HIGHSCHOOL_LIST_ITEM:{json.dumps(processed_item)}")
        return {"type": "HIGHSCHOOL_LIST", "courses": [c.strip() for c in high_school_courses if c and c.strip()]}

    def highschool__high_school_item(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__high_school_item transformer for items: {items}")
        if items and isinstance(items[0], dict) and items[0].get('type') in ['HIGHSCHOOL_COURSE', 'HIGHSCHOOL_PHRASE']:
            return items[0]
        return {"type": "HIGHSCHOOL_ITEM_ERROR", "items": [self._transform_child(item) for item in items]}

    def highschool__grade_12u_course(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__grade_12u_course transformer for items: {items}")
        # Items are GRADE, NUMBER, DIGITU, WORD+
        grade = str(items[0].value).strip() if isinstance(items[0], Token) else ""
        number = str(items[1].value).strip() if isinstance(items[1], Token) else ""
        digitu = str(items[2].value).strip() if isinstance(items[2], Token) else ""
        rest_of_name = " ".join([str(item.value).strip() for item in items[3:] if isinstance(item, Token) and item.type == 'WORD'])
        full_name = f"{grade} {number}{digitu} {rest_of_name}".strip()
        return {"type": "HIGHSCHOOL_COURSE", "name": full_name}

    def highschool__four_u_course(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__four_u_course transformer for items: {items}")
        # Items are DIGITU, WORD+
        digitu = str(items[0].value).strip() if isinstance(items[0], Token) else ""
        rest_of_name = " ".join([str(item.value).strip() for item in items[1:] if isinstance(item, Token) and item.type == 'WORD'])
        full_name = f"{digitu} {rest_of_name}".strip()
        return {"type": "HIGHSCHOOL_COURSE", "name": full_name}

    def highschool__oac_course(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__oac_course transformer for items: {items}")
        # Items are OAC, WORD+
        oac_token = str(items[0].value).strip() if isinstance(items[0], Token) else ""
        rest_of_name = " ".join([str(item.value).strip() for item in items[1:] if isinstance(item, Token) and item.type == 'WORD'])
        full_name = f"{oac_token} {rest_of_name}".strip()
        return {"type": "HIGHSCHOOL_COURSE", "name": full_name}

    def highschool__generic_high_school_phrase(self, items):
        if self.debug:
            print(f"DEBUG: Entering highschool__generic_high_school_phrase transformer for items: {items}")
        # This will be a sequence of WORD, NUMBER, etc.
        text_parts = []
        for item in items:
            if isinstance(item, Token):
                text_parts.append(str(item.value).strip())
            elif isinstance(item, str): # In case a child rule directly returned a string
                text_parts.append(item.strip())
            # For tree nodes, transform them and append their meaningful content if applicable
            elif isinstance(item, Tree):
                transformed_item = self.transform(item)
                if isinstance(transformed_item, dict) and 'name' in transformed_item: # From specific highschool course types
                    text_parts.append(transformed_item['name'])
                elif isinstance(transformed_item, dict) and 'text' in transformed_item: # From generic_high_school_phrase recursion (unlikely)
                    text_parts.append(transformed_item['text'])
                elif isinstance(transformed_item, str):
                    text_parts.append(transformed_item)
                else:
                    if self.debug:
                        print(f"WARNING: generic_high_school_phrase unhandled transformed item: {transformed_item}")
                    text_parts.append(str(transformed_item).strip()) # Fallback for unhandled transformed item
            else:
                if self.debug:
                    print(f"WARNING: generic_high_school_phrase unhandled item type: {type(item)} - {item}")
                text_parts.append(str(item).strip())

        full_text = " ".join(text_parts).strip()
        # Handle "or equivalent" that might be part of this phrase
        # Split by "or" and clean up. This is a heuristic.
        if "OR" in full_text.upper():
            parts = [p.strip() for p in re.split(r'\bOR\b', full_text, flags=re.IGNORECASE)]
            return {"type": "HIGHSCHOOL_PHRASE", "text": parts} # Return as a list of alternatives
        
        return {"type": "HIGHSCHOOL_PHRASE", "text": full_text}


    def nof_expression(self, items):
        if self.debug:
            print(f"DEBUG: Entering nof_expression transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: nof_expression item[{i}]: Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}, Item Content: {item}")

        if len(items) == 1:
            result = items[0]
            if self.debug:
                if isinstance(result, dict) and result.get('type') == 'NOF':
                    print(f"  DEBUG: nof_expression returning direct NOF dict: {result}")
                else:
                    print(f"WARNING: nof_expression (len 1) received unexpected item type: {type(result)}, content: {result}")
            return result
        elif len(items) == 3:
            nof_clause_data = items[1]
            if self.debug:
                if isinstance(nof_clause_data, dict) and nof_clause_data.get('type') == 'NOF':
                    print(f"  DEBUG: nof_expression returning NOF dict from LPAR...RPAR: {nof_clause_data}")
                else:
                    print(f"WARNING: nof_expression (len 3) middle item unexpected type: {type(nof_clause_data)}, content: {nof_clause_data}")
            return nof_clause_data
        else:
            if self.debug:
                print(f"WARNING: nof_expression received unexpected number of items: {len(items)}, content: {items}")
            return {"type": "NOF_EXPRESSION_ERROR", "original_items": [self._transform_child(item) for item in items]}


    def nof_clause(self, items):
        if self.debug:
            print(f"DEBUG: Entering nof_clause transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: nof_clause item[{i}]: Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}, Item Content: {item}")

        number = None
        courses: List[str] = []
        
        if len(items) >= 3:
            number_token = items[0]
            if isinstance(number_token, Token) and number_token.type == 'NUMBER': 
                try:
                    number = int(str(number_token.value))
                    if self.debug:
                        print(f"  DEBUG: nof_clause - Extracted number: {number}")
                except ValueError:
                    if self.debug:
                        print(f"WARNING: nof_clause could not convert '{number_token.value}' to int.")
            else:
                if self.debug:
                    print(f"WARNING: nof_clause expected NUMBER token at index 0, but got: {number_token}")

            courses_data_from_list = items[2] # This is the result from 'course_list' or 'high_school_list'
            
            # This part needs to be robust for both 'COURSES' and 'HIGHSCHOOL_LIST'
            if isinstance(courses_data_from_list, dict):
                if courses_data_from_list.get('type') == 'COURSES' and 'courses' in courses_data_from_list:
                    if self.debug:
                        print(f"  DEBUG: nof_clause - Found transformed COURSES dict: {courses_data_from_list}")
                    courses.extend([c.strip() for c in courses_data_from_list.get('courses', []) if isinstance(c, str) and c.strip()])
                elif courses_data_from_list.get('type') == 'HIGHSCHOOL_LIST' and 'courses' in courses_data_from_list:
                    if self.debug:
                        print(f"  DEBUG: nof_clause - Found transformed HIGHSCHOOL_LIST dict: {courses_data_from_list}")
                    courses.extend([c.strip() for c in courses_data_from_list.get('courses', []) if isinstance(c, str) and c.strip()])
                elif courses_data_from_list.get('type') == 'HIGHSCHOOL_COURSE' and 'name' in courses_data_from_list:
                     courses.append(courses_data_from_list['name'].strip())
                elif courses_data_from_list.get('type') == 'HIGHSCHOOL_PHRASE' and isinstance(courses_data_from_list.get('text'), list):
                    courses.extend([t.strip() for t in courses_data_from_list['text'] if isinstance(t, str) and t.strip()])
                elif courses_data_from_list.get('type') == 'HIGHSCHOOL_PHRASE' and isinstance(courses_data_from_list.get('text'), str):
                    courses.append(courses_data_from_list['text'].strip())
                else:
                    if self.debug:
                        print(f"WARNING: nof_clause expected 'COURSES' or 'HIGHSCHOOL_LIST' dict at index 2 but got: {courses_data_from_list}")
                    courses.append(f"UNRESOLVED_COURSES_LIST:{json.dumps(courses_data_from_list)}")
            else:
                if self.debug:
                    print(f"WARNING: nof_clause expected dict at index 2 but got non-dict: {courses_data_from_list}")
                courses.append(f"UNRESOLVED_COURSES_LIST:{str(courses_data_from_list)}")
        else:
            if self.debug:
                print(f"WARNING: nof_clause received unexpected number of items: {len(items)}, expected 3.")


        if number is not None and courses:
            result = {"type": "NOF", "number": number, "courses": courses}
        else:
            if self.debug:
                print(f"DEBUG: nof_clause missing data (number={number}, courses={courses}): original_items={[self._transform_child(i) for i in items]}")
            result = {"type": "NOF_ERROR", "original_items": [self._transform_child(item) for item in items]}
        
        if self.debug:
            print(f"DEBUG: Exiting nof_clause transformer with result: {result}")
        return result


    def credit_with_includes(self, items):
        if self.debug:
            print(f"DEBUG: Entering credit_with_includes transformer for items: {items}")
            for i, item in enumerate(items):
                print(f"  DEBUG: credit_with_includes item[{i}]: Type={type(item)}, Data={getattr(item, 'data', None)}, Value={getattr(item, 'value', None)}")

        offset = 1 if isinstance(items[0], Token) and items[0].type == 'COMPLETION_OF' else 0
        
        credits_token = items[offset]
        credits_amount = None
        if isinstance(credits_token, Token) and credits_token.type == 'DECIMAL':
            try:
                credits_amount = float(credits_token.value)
            except ValueError:
                if self.debug:
                    print(f"WARNING: credit_with_includes could not convert {credits_token.value} to float.")
                credits_amount = 0.0
        
        flat_includes: List[Any] = []

        for item_index in range(offset + 3, len(items)):
            item = items[item_index]
            processed_item = self.transform(item) if isinstance(item, Tree) else item

            if self.debug:
                print(f"  DEBUG: credit_with_includes - Processed item: Type={type(processed_item)}, Content={processed_item}")

            if isinstance(processed_item, dict):
                if processed_item.get("type") == "COURSES" and "courses" in processed_item:
                    flat_includes.extend([c.strip() for c in processed_item["courses"] if isinstance(c, str) and c.strip()])
                elif processed_item.get("type") == "NOF":
                    flat_includes.append(processed_item)
                elif processed_item.get("type") == "CREDITS_AMOUNT":
                    flat_includes.append(processed_item)
                elif processed_item.get("type") == "SINGLE_COURSE":
                    if isinstance(processed_item.get("course"), str):
                        stripped_course = processed_item["course"].strip()
                        if stripped_course: 
                            flat_includes.append(stripped_course)
                    else:
                        if self.debug:
                            print(f"DEBUG: credit_with_includes - Single course value not string: {processed_item}")
                        flat_includes.append(processed_item)
                # NEW: Handle High School courses from highschool grammar
                elif processed_item.get('type') == 'HIGHSCHOOL_COURSE' and 'name' in processed_item:
                    stripped_name = processed_item['name'].strip()
                    if stripped_name:
                        flat_includes.append(stripped_name)
                # NEW: Handle generic high school phrases from highschool grammar
                elif processed_item.get('type') == 'HIGHSCHOOL_PHRASE' and 'text' in processed_item:
                    # If it's a list (from "or" split), extend; otherwise, append
                    if isinstance(processed_item['text'], list):
                        flat_includes.extend([t.strip() for t in processed_item['text'] if isinstance(t, str) and t.strip()])
                    else:
                        stripped_text = processed_item['text'].strip()
                        if stripped_text:
                            flat_includes.append(stripped_text)
                elif processed_item.get("type") == "COURSE_SEQUENCE": 
                    if "courses" in processed_item and isinstance(processed_item["courses"], list):
                        flat_includes.extend([c.strip() for c in processed_item["courses"] if isinstance(c, str) and c.strip()])
                    else:
                        if self.debug:
                            print(f"WARNING: credit_with_includes - COURSE_SEQUENCE unexpected structure: {processed_item}")
                        flat_includes.append(processed_item)
                else:
                    if self.debug:
                        print(f"DEBUG: credit_with_includes - Unhandled transformed dict type: {processed_item.get('type')}, {processed_item}")
                    flat_includes.append(processed_item)
            elif isinstance(processed_item, Token):
                stripped_value = processed_item.value.strip()
                if stripped_value: 
                    if self.debug:
                        print(f"  DEBUG: credit_with_includes - Appending raw token: {processed_item.type}, {stripped_value}")
                    flat_includes.append({"type": processed_item.type, "value": stripped_value})
                else:
                    if self.debug:
                        print(f"  DEBUG: credit_with_includes - Ignoring empty token after strip: {processed_item.type}, {processed_item.value}")
            else:
                if self.debug:
                    print(f"DEBUG: credit_with_includes - Appending other item type: {type(processed_item)}, {processed_item}")
                stripped_item = str(processed_item).strip()
                if stripped_item: 
                    flat_includes.append(stripped_item)

        result = {
            "type": "CREDITS_WITH_INCLUDES",
            "credits": credits_amount,
            "includes": flat_includes,
            "raw": None
        }
        if self.debug:
            print(f"DEBUG: Exiting credit_with_includes transformer with result: {result}")
        return result
    
    def _transform_child(self, child):
        if isinstance(child, dict):
            return child
        elif isinstance(child, Tree):
            return self.transform(child)
        elif isinstance(child, Token):
            stripped_value = child.value.strip()
            if stripped_value:
                return {"type": child.type, "value": stripped_value}
            else:
                return {"type": child.type, "value": "<EMPTY_STRIPPED_TOKEN>"} 
        return child

    def _transform_children_for_error(self, children):
        transformed_error_children = []
        for child in children:
            if isinstance(child, dict):
                transformed_error_children.append(child)
            elif isinstance(child, Tree):
                transformed_error_children.append({"data": child.data, "raw_children_count": len(child.children)})
            elif isinstance(child, Token):
                stripped_value = child.value.strip()
                if stripped_value:
                    transformed_error_children.append({"type": child.type, "value": stripped_value})
                else:
                    transformed_error_children.append({"type": child.type, "value": "<EMPTY_STRIPPED_TOKEN>"})
            else:
                stripped_item = str(child).strip()
                if stripped_item:
                    transformed_error_children.append(stripped_item)
                else:
                    transformed_error_children.append("<EMPTY_STRIPPED_ITEM>")
        return transformed_error_children


    def __default__(self, data, children, meta):
        if self.debug:
            print(f"DEBUG: Entering __default__ transformer for data='{data}', children={children}")
        transformed_children = []
        for child in children:
            if isinstance(child, dict):
                transformed_children.append(child)
            elif isinstance(child, Tree):
                transformed_children.append(self.transform(child))
            elif isinstance(child, Token):
                stripped_value = child.value.strip()
                if stripped_value:
                    transformed_children.append({"type": child.type, "value": stripped_value})
                else:
                    if self.debug:
                        print(f"  DEBUG: __default__ - Ignoring empty token after strip: {child.type}, {child.value}")
            else:
                stripped_item = str(child).strip()
                if stripped_item:
                    transformed_children.append(stripped_item)
                else:
                    if self.debug:
                        print(f"  DEBUG: __default__ - Ignoring empty item after strip: {type(child)}, {child}")
        result = {"type": str(data), "children": transformed_children}
        if self.debug:
            print(f"DEBUG: Exiting __default__ transformer with result: {result}")
        return result

# Grammar mapping and parser instantiation
GRAMMAR_MAP = {
    "courses": ("courses.lark", "start"),
    "credits": ("credits.lark", "start"),
    "credits_includes": ("credits_includes.lark", "start"),
    "nof": ("nof.lark", "start"),
    "phase": ("phase.lark", "start"),
    "highschool": ("highschool.lark", "start"), # Kept 'highschool' here
    "experience": ("experience.lark", "start"), 
    "program": ("program.lark", "start"),
    "average": ("average.lark", "start"),
    "admission": ("admission.lark", "start"),
    "progression": ("progression.lark", "start"),
    "workterm": ("workterm.lark", "start"),
    "generic": ("generic.lark", "start"),
}

PARSERS = {}
for cat, (fname, start) in GRAMMAR_MAP.items():
    grammar_path = (GRAMMAR_DIR / fname).resolve()
    print(f"DEBUG: Loading grammar for category '{cat}' from: {grammar_path}")
    if not grammar_path.exists():
        print(f"ERROR: Grammar file not found at {grammar_path}")
    PARSERS[cat] = Lark.open(
        str(grammar_path), parser="earley", start=start,
        propagate_positions=True, maybe_placeholders=False,
        import_paths=[str(GRAMMAR_DIR)]
    )

def parse_chunk(chunk: str, category: str, debug: bool = False):
    parser = PARSERS.get(category)
    if not parser:
        raise ValueError(f"No parser for category '{category}'")
    if not chunk or not isinstance(chunk, str):
        raise ValueError(f"Invalid chunk: {chunk}")
    
    parsed_tree = parser.parse(chunk.upper())
    
    if debug:
        print("\n--- Raw Parsed Tree ---")
        print(parsed_tree.pretty())
        print("-----------------------\n")
    
    transformed_data = RequisiteTransformer(debug=debug).transform(parsed_tree)
    
    if debug:
        print("\n--- Transformed Data (Before Return) ---")
        try:
            print(json.dumps(transformed_data, indent=2))
        except TypeError as e:
            print(f"Error serializing transformed data for debug print: {e}")
            print(transformed_data)
        print("----------------------------------------\n")
        
    return transformed_data

def safe_parse(chunk: str, category: str, debug: bool = False):
    try:
        return parse_chunk(chunk, category, debug=debug)
    except (UnexpectedInput, ValueError) as e:
        if debug:
            print(f"DEBUG: safe_parse error: {e}")
        return {"type": "ERROR", "category": category, "chunk": chunk, "error": str(e)}