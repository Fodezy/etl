# File: src/parser/split.py
import re
from typing import List

DERAIL_PATTERN = re.compile(r"\s*[-–]\s*Must\b.*", re.IGNORECASE)

# This is the list of words that stops the splitter from looking deeper.
# If a chunk contains any of these, it's considered a single, indivisible unit.
DISQUALIFY_RE = re.compile(
    r"\b(credit|credits|including|minimum|grade|average|%|"
    r"registration|admission|semester|experience|1 of)\b",
    re.IGNORECASE
)

def _is_fully_enclosed(text: str) -> bool:
    """
    Checks if a string is fully enclosed by matching parentheses or brackets.
    """
    text = text.strip()
    if not ((text.startswith('(') and text.endswith(')')) or \
            (text.startswith('[') and text.endswith(']'))):
        return False
    open_char, close_char = text[0], text[-1]
    depth = 0
    for char in text[1:-1]:
        if char == open_char: depth += 1
        elif char == close_char: depth -= 1
        if depth < 0: return False
    return True

def _split_on_top_level_or(text: str) -> List[str]:
    """
    Splits a string ONCE on the first "or" that is not inside nesting.
    """
    paren_depth = 0
    bracket_depth = 0
    or_finder = re.compile(r'\bor\b', re.IGNORECASE)
    for match in or_finder.finditer(text):
        or_position = match.start()
        sub_string = text[:or_position]
        paren_depth = sub_string.count('(') - sub_string.count(')')
        bracket_depth = sub_string.count('[') - sub_string.count(']')
        if paren_depth == 0 and bracket_depth == 0:
            left = text[:or_position].strip()
            right = text[match.end():].strip()
            if left and right: return [left, right]
    return [text]

def split_commas_outside_nesting(text: str) -> List[str]:
    """
    Splits on top-level commas/semicolons and cleans quotes from each part.
    """
    parts: List[str] = []
    current: List[str] = []
    paren_depth = 0
    bracket_depth = 0
    for ch in text:
        if ch == '(': paren_depth += 1
        elif ch == ')': paren_depth = max(paren_depth - 1, 0)
        elif ch == '[': bracket_depth += 1
        elif ch == ']': bracket_depth = max(bracket_depth - 1, 0)
        
        if ch in {",", ";"} and paren_depth == 0 and bracket_depth == 0:
            part = "".join(current).strip()
            if (part.startswith('"') and part.endswith('"')) or \
               (part.startswith("'") and part.endswith("'")):
                part = part[1:-1]
            if part: parts.append(part)
            current = []
        else:
            current.append(ch)
            
    last = "".join(current).strip()
    if (last.startswith('"') and last.endswith('"')) or \
       (last.startswith("'") and last.endswith("'")):
        last = last[1:-1]
    if last: parts.append(last)
    return parts

def split_courses(raw: str) -> List[str]:
    """
    Given a raw prerequisite string, return a list of candidate course chunks.
    """
    if not raw: return []
    chunks: List[str] = []
    cleaned = DERAIL_PATTERN.sub("", raw).strip()
    
    # First, do a simple top-level split. This separates major clauses.
    initial_parts = split_commas_outside_nesting(cleaned)

    for part in initial_parts:
        p = part.strip().rstrip(".")
        if not p: continue

        # *** NEW SIMPLIFIED LOGIC ***
        # Rule 1: Does this part contain a disqualifying keyword?
        # If so, it's a single chunk. Do not process it further.
        if DISQUALIFY_RE.search(p):
            chunks.append(p)
            continue

        # Rule 2: If not disqualified, is it a bracketed list?
        # If so, open it and split the contents.
        if _is_fully_enclosed(p):
            content_to_split = p[1:-1]
            # Recursively split the inner content
            inner_parts = split_commas_outside_nesting(content_to_split)
            for inner_part in inner_parts:
                chunks.extend(_split_on_top_level_or(inner_part))
        else:
            # Rule 3: If it's simple text, just split by "or".
            chunks.extend(_split_on_top_level_or(p))
            
    return chunks