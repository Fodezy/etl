# File: src/parser/classify.py

"""
classify.py

Provides classification logic for the “courses” category.
Exports a single entrypoint `classify(chunk: str) -> str` that returns:
  - 'courses' if the chunk is a pure course list
  - 'generic' otherwise
"""

import re
from typing import List
from .split import split_courses

# Regex to detect valid COURSE_CODEs
COURSE_RE = re.compile(r"\b[A-Z]{2,6}\*\d{4}\b")

# Any of these keywords disqualifies a chunk from being pure courses
DISQUALIFY_RE = re.compile(
    r"\b(credit|credits|including|minimum|grade|average|%|"
    r"registration|admission|semester|experience)\b",
    re.IGNORECASE
)

def is_course_chunk(chunk: str) -> bool:
    """
    Return True if the chunk is a pure courses list.
    A pure course list is one that matches one of the known patterns
    for course requirements and does not contain disqualifying keywords.
    """
    text = chunk.strip()
    # Disqualify if it contains keywords like 'credit', 'grade', etc.
    if DISQUALIFY_RE.search(text):
        return False
    # Must contain at least one course code to be considered
    if not COURSE_RE.search(text):
        return False

    # --- Start of new logic ---

    # A pattern for a single course code like "DEPT*1234"
    course_code_pattern = r"[A-Z]{2,6}\*\d{4}"

    # A pattern for a simple group of courses in parentheses like "(A, B, C)"
    paren_group_pattern = r"\(\s*" + course_code_pattern + r"(?:\s*,\s*" + course_code_pattern + r")*\s*\)"

    # An "item" can be either a single course OR a parenthesized group
    item_pattern = r"(?:" + course_code_pattern + r"|" + paren_group_pattern + r")"

    # --- End of new logic ---

    # Pattern 1: A single course code (e.g., "MDST*1080")
    if COURSE_RE.fullmatch(text):
        return True

    # Pattern 2: A bracketed/parenthesized list that can now contain nested groups
    # e.g., "[(A, B) or C]"
    if re.fullmatch(
        r"^[\(\[]\s*" +
        item_pattern +
        r"(?:\s*(?:,|\bor\b|\band\b)\s*" + item_pattern + r")*" +
        r"\s*[\)\]]$",
        text, flags=re.IGNORECASE
    ):
        return True

    # Pattern 3: An un-grouped list of courses (e.g., "A or B", "A and B")
    if re.fullmatch(
        r"^(?:" + course_code_pattern + r"\s*(?:or|and)\s*)+" + course_code_pattern + r"$",
        text, flags=re.IGNORECASE
    ):
        return True

    # If the chunk doesn't match any of the pure course patterns, it's generic.
    return False

def classify(chunk: str) -> str:
    """
    Classify a chunk: 'courses' if it's a pure course list, else 'generic'.
    """
    return "courses" if is_course_chunk(chunk) else "generic"

