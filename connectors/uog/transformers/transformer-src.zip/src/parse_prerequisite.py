import json
from pathlib import Path
from lark import Tree # Explicitly import Tree for type checking
from typing import Optional
from .parse import parse_prereq # Import the modified parse_prereq function

def main(debug_categories: Optional[list[str]] = None, enable_debug_print: bool = False):
    """
    Parses prerequisite strings from an input JSON file and dumps the results
    to an output JSON file, optionally filtering by specified categories for debugging.

    Args:
        debug_categories: A list of category names (strings) to include in the output.
                          If None (default), results from ALL categories will be included.
                          Example: ['courses', 'credits']
        enable_debug_print: If True, enables verbose debug printing from the parser/transformer.
    """
    here = Path(__file__).resolve().parent
    input_path  = (here.parent.parent / 'raw' / 'subjects_with_courses.json').resolve()
    output_path = (here / 'classification_output.json').resolve()

    if not input_path.exists():
        print(f"Error: input file not found: {input_path}")
        return

    with open(input_path, 'r', encoding='utf-8') as f:
        subjects = json.load(f)

    final_output = []
    for subject, courses in subjects.items():
        for course in courses:
            code = course.get('code', '<unknown>')
            raw  = course.get('requisites', None)

            # Pass the enable_debug_print flag to parse_prereq
            parsed_chunks = parse_prereq(raw, debug=False)

            # Optionally filter by category
            if debug_categories:
                parsed_chunks = [
                    c for c in parsed_chunks
                    if c['category'] in debug_categories
                ]

            # Build per-course record
            final_output.append({
                'subject': subject,
                'code': code,
                'requisites_full_string': raw,
                'chunks': [
                    {
                        'chunk': c['chunk'],
                        'category': c['category'],
                        'parsed': (
                            c['parsed'].pretty()
                            if isinstance(c['parsed'], Tree) and hasattr(c['parsed'], "pretty") # Check if it's a Tree
                            else c['parsed']
                        )
                    }
                    for c in parsed_chunks
                ]
            })

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(final_output, f, indent=2)

    print(f"Wrote {len(final_output)} course entries to {output_path}")


if __name__ == '__main__':
    # --- How to use the new debugging feature ---

    # Option 1: To dump results from ALL categories (default behavior)
    # No extra debug prints
    # main()
    main(debug_categories=['courses'], enable_debug_print=False)

    # Option 2: To dump results ONLY from specific categories AND enable verbose debug prints
    # This is what you'll want to use to diagnose the "Unhandled non-dict item" warnings.
    # We'll focus on 'credits' and 'credits_includes'
    # main(debug_categories=['credits_includes'], enable_debug_print=True)

    # Option 3: To dump results ONLY from the 'generic' category with debug prints
    # main(debug_categories=['generic'], enable_debug_print=True)

    # Remember to delete __pycache__ folders after modifying .lark files:
    # `rd /s /q __pycache__` in your relevant directories before running again.