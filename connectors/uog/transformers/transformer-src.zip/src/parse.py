# File: src/parse.py

from typing import Any, Dict, List, Optional
from .parser.split import split_courses      # your splitter
from .parser.classify import classify        # now matches classify.py
# from .parser.parsers import safe_parse     # Temporarily disabled for classification testing

def parse_prereq(raw_text: str, debug: bool = False) -> List[Dict[str, Any]]:
    """
    Parse a raw prerequisite string into structured data.
    This version is for testing splitting and classification only.

    1. split_courses → produces candidate chunks for 'courses'
    2. classify      → tags each chunk, e.g. 'courses' or 'generic'
    3. safe_parse    → (Temporarily disabled)
    """
    # Short-circuit if no prerequisites
    if raw_text is None or raw_text.strip().lower() in ("", "none", "n/a"):
        if debug:
            print(f"DEBUG: No prerequisites for '{raw_text}'")
        return [{
            "chunk": "",
            "category": "no_requisites",
            "parsed": {} # Empty dict to maintain structure
        }]

    results: List[Dict[str, Any]] = []
    # The split_courses function provides clean chunks.
    for i, chunk in enumerate(split_courses(raw_text)):

        if debug:
            print(f"\nDEBUG: chunk {i+1}: '{chunk}'")

        category = classify(chunk)
        if debug:
            print(f"DEBUG: classified as '{category}'")

        # The call to the Lark parser is disabled.
        # parsed = safe_parse(chunk, category, debug=debug)
        
        # We will just store the chunk and its category.
        results.append({
            "chunk": chunk,
            "category": category,
            # The 'parsed' key is included with a placeholder to maintain a consistent data shape.
            "parsed": {} 
        })

    return results
