"""
N-of Transformer for Course Prerequisites

This module provides a transformer for "N of courses" expressions in course prerequisites.
It converts the parsed AST from the nof.lark grammar into a structured dictionary.
"""

from lark import Transformer, Tree, Token
from typing import Dict, List, Any, Optional
import re

class NofTransformer(Transformer):
    """
    Transformer for "N of courses" expressions in prerequisites.
    
    This transformer converts the parsed AST from nof.lark into a structured dictionary
    with the following format:
    {
        "type": "NOF",
        "number": <int>,
        "courses": [<course_code>, ...]
    }
    """
    
    def __init__(self, debug: bool = False):
        self.debug = debug
        super().__init__()
    
    def start(self, items):
        """Transform the start rule."""
        if self.debug:
            print(f"DEBUG: 'start' rule transformed. Items: {items}")
        
        if items and len(items) == 1:
            return items[0]
        
        return {"type": "NOF_ERROR", "error": "Unexpected start structure"}
    
    def nof_expression(self, items):
        """Transform the nof_expression rule."""
        if self.debug:
            print(f"DEBUG: 'nof_expression' rule transformed. Items: {items}")
        
        # Handle direct nof_clause
        if len(items) == 1:
            return items[0]
        
        # Handle parenthesized nof_clause (LPAR nof_clause RPAR)
        elif len(items) == 3:
            # Middle item should be the nof_clause result
            return items[1]
        
        return {"type": "NOF_ERROR", "error": "Unexpected nof_expression structure"}
    
    def nof_clause(self, items):
        """Transform the nof_clause rule."""
        if self.debug:
            print(f"DEBUG: 'nof_clause' rule transformed. Items: {items}")
        
        # Extract the number (first item)
        number = None
        if isinstance(items[0], Token) and items[0].type == 'NUMBER':
            try:
                number = int(items[0].value)
            except ValueError:
                if self.debug:
                    print(f"WARNING: Could not convert '{items[0].value}' to int.")
        
        # Extract courses (third item, after "of")
        courses = []
        if len(items) >= 3:
            course_list = items[2]
            if isinstance(course_list, dict) and course_list.get("type") == "COURSES":
                courses = course_list.get("courses", [])
            elif isinstance(course_list, list):
                courses = course_list
        
        if number is not None and courses:
            return {"type": "NOF", "number": number, "courses": courses}
        
        return {"type": "NOF_ERROR", "error": "Missing number or courses"}
    
    def course_list(self, items):
        """Transform the course_list rule."""
        if self.debug:
            print(f"DEBUG: 'course_list' rule transformed. Items: {items}")
        
        courses = []
        for item in items:
            if isinstance(item, dict) and "courses" in item:
                courses.extend(item["courses"])
            elif isinstance(item, str):
                courses.append(item)
            elif isinstance(item, Token) and item.type == 'COURSE_CODE':
                courses.append(item.value)
        
        return {"type": "COURSES", "courses": courses}
    
    def __default__(self, data, children, meta):
        """Default transformation for unhandled rules."""
        if self.debug:
            print(f"DEBUG: Default transformation for {data} with {len(children)} children")
        
        # Pass through transformed children
        if len(children) == 1:
            return children[0]
        return children


def transform_nof(parsed_tree, debug=False):
    """
    Transform a parsed nof expression tree into a structured dictionary.
    
    Args:
        parsed_tree: The parsed tree from the nof.lark grammar
        debug: Whether to print debug information
        
    Returns:
        A dictionary with the structure:
        {
            "type": "NOF",
            "number": <int>,
            "courses": [<course_code>, ...]
        }
    """
    transformer = NofTransformer(debug=debug)
    return transformer.transform(parsed_tree)